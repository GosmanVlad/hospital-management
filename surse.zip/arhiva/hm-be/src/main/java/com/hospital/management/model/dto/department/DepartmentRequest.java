package com.hospital.management.model.dto.department;

import lombok.Data;

@Data
public class DepartmentRequest {
    private String departmentName;
}
