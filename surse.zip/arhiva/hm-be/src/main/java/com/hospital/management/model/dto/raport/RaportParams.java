package com.hospital.management.model.dto.raport;

import lombok.Data;

@Data
public class RaportParams {
    private Long doctorId;
    private Long patientId;
}
