package com.hospital.management.exception.appointment;

public class AppointmentFieldsException extends Exception{
    public AppointmentFieldsException(String errorMessage){
        super(errorMessage);
    }
}
