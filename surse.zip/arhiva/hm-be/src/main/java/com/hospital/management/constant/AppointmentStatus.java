package com.hospital.management.constant;

public class AppointmentStatus {
    public static final String PENDING = "pending";
    public static final String ACCEPTED = "accepted";
    public static final String DECLINED = "declined";
    public static final String CANCELED = "canceled";
}
