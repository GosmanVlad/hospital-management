package com.hospital.management.model.dto.raport;

import lombok.Data;

@Data
public class PieRaportOutcomingDto {
    private int hospitalizations;
    private int appointments;
}
