package com.hospital.management.exception.salon;

public class SalonSeatsException extends Exception{
    public SalonSeatsException(String errorMessage){
        super(errorMessage);
    }
}
