const snackbarColors = {
    warning: "#cc9900",
    error: "error",
    success: "success"
};

export { snackbarColors };