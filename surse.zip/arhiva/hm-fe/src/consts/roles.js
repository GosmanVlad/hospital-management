const roles = [
    { key: '', value: "Toate" },
    { key: 'NURSE', value: "Asistent" },
    { key: 'DOCTOR', value: "Doctor" }];


export { roles }