<template>
    <h3 class="page-title">Personal si pacienti</h3>
    <PeopleComponent />
</template>
<script>
import PeopleComponent from '@/components/People/PeopleComponent.vue';
export default {
    name: "PeoplePage",
    components: { PeopleComponent },
}
</script>
