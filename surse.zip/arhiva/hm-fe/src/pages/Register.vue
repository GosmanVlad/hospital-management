<template>
    <Register />
</template>
<script>
import Register from '@/components/Auth/Register.vue';
export default {
    name: "registerPage",
    components: { Register },
}
</script>
