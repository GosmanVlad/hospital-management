<template>
    <DashboardComponent />
</template>
<script>
import DashboardComponent from "@/components/DashboardComponent.vue";

export default {
    name: "HomePage",
    components: { DashboardComponent }
}
</script>
