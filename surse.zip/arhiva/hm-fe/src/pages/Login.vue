<template>
    <Login />
</template>
<script>
import Login from '@/components/Auth/Login.vue';
export default {
    name: "loginPage",
    components: { Login },
}
</script>
