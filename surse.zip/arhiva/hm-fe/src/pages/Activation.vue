<template>
    <Activation />
</template>
<script>
import Activation from '@/components/Auth/Activation.vue';
export default {
    name: "activationPage",
    components: { Activation },
}
</script>
